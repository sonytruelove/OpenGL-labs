#ifndef GRAPHIC_H_INCLUDED
#define GRAPHIC_H_INCLUDED

GLuint texture_Load(char *filename,int cnt=3);
void show_Texture(GLuint textrureID, RECT texsize);
void RenderSpriteAnimation(GLuint texture, float posX, float posY, float width, float height, float scale,int currentFrame);
void UpdateAnimationFrame(int &currentFrame,int totalFrames);
#endif // GRAPHIC_H_INCLUDED


